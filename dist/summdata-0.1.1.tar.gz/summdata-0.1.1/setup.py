from setuptools import setup

setup(name='summdata',
      version='0.1.1',
      description='Python Summary Statistics',
      author='Isabelle Vea',
      author_email='isabelle.vea@gmail.com',
      packages=['summdata'],
      zip_safe=False)