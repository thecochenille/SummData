from setuptools import setup

setup(name='summdata',
      version='0.1',
      description='Summary Statistics',
      packages=['summdata'],
      zip_safe=False)